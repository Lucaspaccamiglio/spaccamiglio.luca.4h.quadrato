﻿using System;

namespace spaccamiglio.luca._4h.quadrato
{
    class Program
    {
        static void Main(string[] args)
        {
            Q Quadrato1 = new Q(9);
            Q Quadrato2 = new Q(11);

            Console.WriteLine($"Lato:{Quadrato1.Lato} \nPerimetro: {Quadrato1.Perimetro()} \nArea: {Quadrato1.Area()} \nDiagonale {Quadrato1.Diagonale()} ");

            if (Quadrato1 > Quadrato2)
                Console.WriteLine("il quadrato q1 e maggiore del quadrato q2 ");
            else
                Console.WriteLine("il quadrato q1 e minore del quadrato q2 ");
            
        }
    }
}
class Q
{
    public Q() { }//costruttore
    public Q(double l)
    {
        Lato = l;
    }

    double _lato;
    public double Lato {
        get
        {
            return _lato;
        }

        set
        {
            _lato = value;
        }
    }

    double _posx;
    public double Posx
    {
        get
        {
            return _posx;
        }

        set
        {
            _posx = value;
        }
    }

    double _posy;
    public double Posy
    {
        get
        {
            return _posy;
        }

        set
        {
            _posy = value;
        }
    }
    public double Perimetro()//metodo perimetro
    {

        return Lato * 4;

    }

    public double Area()//metodo area
    {

        return Lato * Lato;

    }

    public double Diagonale()//metodo diagono
    {

        return Math.Round(Lato * Math.Sqrt(2), 2);

    }

    //sovraccarico dell'operatore logico >
    public static bool operator > (Q Quadrato1, Q Quadrato2)
    {
        if (Quadrato1.Area() > Quadrato2.Area())
            return true;
        else
            return false;
    }

    public static bool operator < (Q Quadrato1, Q Quadrato2)
    {
        if (Quadrato1.Area() > Quadrato2.Area())
            return true;
        else
            return false;
    }
}